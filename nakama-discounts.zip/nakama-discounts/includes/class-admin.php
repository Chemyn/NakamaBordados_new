<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Administración: WooCommerce > Nakama Descuentos.
 * Incluye el apartado dedicado de CAMPAÑAS ESPECIALES (activar/desactivar)
 * con estado en vivo, más los parámetros generales y el aviso de Mi Cuenta.
 */
class Nakama_Admin {

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register' ) );
	}

	public static function menu() {
		add_submenu_page(
			'woocommerce',
			'Nakama Descuentos',
			'Nakama Descuentos',
			'manage_woocommerce',
			'nakama-discounts',
			array( __CLASS__, 'render' )
		);
	}

	public static function register() {
		register_setting( 'nakama_discounts_group', NAKAMA_DISC_OPTION, array(
			'sanitize_callback' => array( __CLASS__, 'sanitize' ),
		) );
		register_setting( 'nakama_discounts_group', NAKAMA_DISC_CODES_OPTION, array(
			'sanitize_callback' => array( 'Nakama_Discount_Codes', 'sanitize' ),
		) );
	}

	public static function sanitize( $input ) {
		$out = Nakama_Settings::all();

		$checkboxes = array(
			'welcome_enabled', 'welcome_account_only',
			'special_10_enabled', 'special_3x2_enabled', 'special_auto_if_better',
			'free_ship_enabled', 'transfer_enabled', 'msi_enabled',
			'account_notice_enabled', 'account_notice_complete',
		);
		foreach ( $checkboxes as $c ) {
			$out[ $c ] = isset( $input[ $c ] ) ? 'yes' : 'no';
		}

		$floats = array(
			'welcome_rate_1', 'welcome_rate_2', 'welcome_rate_3',
			'special_10_rate', 'transfer_rate',
			'free_ship_threshold', 'free_ship_cap',
			'msi_3_threshold', 'msi_6_threshold',
		);
		foreach ( $floats as $f ) {
			if ( isset( $input[ $f ] ) ) {
				$out[ $f ] = (float) $input[ $f ];
			}
		}

		foreach ( array( 'welcome_days_2', 'welcome_days_3' ) as $i ) {
			if ( isset( $input[ $i ] ) ) {
				$out[ $i ] = (int) $input[ $i ];
			}
		}

		$texts = array(
			'transfer_gateway_id',
			'special_10_start', 'special_10_end',
			'special_3x2_start', 'special_3x2_end',
		);
		foreach ( $texts as $t ) {
			if ( isset( $input[ $t ] ) ) {
				$out[ $t ] = sanitize_text_field( $input[ $t ] );
			}
		}

		if ( isset( $input['special_3x2_categories'] ) ) {
			$out['special_3x2_categories'] = array_filter( array_map( 'sanitize_title',
				array_map( 'trim', explode( ',', $input['special_3x2_categories'] ) )
			) );
		}

		// Overrides por moneda (texto "USD:80" -> array).
		foreach ( array( 'free_ship_threshold_map', 'free_ship_cap_map', 'msi_3_threshold_map', 'msi_6_threshold_map' ) as $mk ) {
			if ( isset( $input[ $mk ] ) ) {
				$out[ $mk ] = Nakama_Settings::parse_currency_map( $input[ $mk ] );
			}
		}

		return $out;
	}

	/** Pill de estado en vivo para una campaña. */
	private static function status_pill( $active ) {
		if ( $active ) {
			return '<span style="display:inline-block;padding:2px 10px;border-radius:999px;background:#dcfce7;color:#166534;font-size:12px;font-weight:600;">● Activa ahora</span>';
		}
		return '<span style="display:inline-block;padding:2px 10px;border-radius:999px;background:#f3f4f6;color:#6b7280;font-size:12px;font-weight:600;">○ Inactiva</span>';
	}

	private static function entry_mode_label( $entry_mode ) {
		return Nakama_Discount_Codes::ENTRY_MANUAL === $entry_mode
			? esc_html__( 'Manual', 'nakama-discounts' )
			: esc_html__( 'Automático', 'nakama-discounts' );
	}

	public static function render() {
		$s   = Nakama_Settings::all();
		$opt = NAKAMA_DISC_OPTION;
		$codes = Nakama_Discount_Codes::all();
		$codes_opt = NAKAMA_DISC_CODES_OPTION;
		$cb  = function ( $key ) use ( $s ) {
			return checked( 'yes', $s[ $key ], false );
		};
		?>
		<div class="wrap">
			<h1>Nakama Descuentos</h1>
			<?php settings_errors( NAKAMA_DISC_CODES_OPTION ); ?>
			<form method="post" action="options.php">
				<?php settings_fields( 'nakama_discounts_group' ); ?>

				<!-- ================= CÓDIGOS PÚBLICOS ================= -->
				<section class="nakama-code-admin" aria-labelledby="nakama-public-codes-title">
					<div class="nakama-code-admin__heading">
						<div>
							<h2 id="nakama-public-codes-title">Códigos públicos</h2>
							<p class="description">Aparecen como opciones en checkout. Solo una promoción principal puede aplicarse por pedido.</p>
						</div>
					</div>

					<?php if ( empty( $codes ) ) : ?>
						<p class="nakama-code-empty">Todavía no hay códigos públicos. Crea el primero cuando quieras publicar un descuento porcentual.</p>
					<?php else : ?>
						<div class="nakama-code-list">
							<?php foreach ( $codes as $id => $code ) :
								$status = Nakama_Discount_Codes::status( $code );
								$entry_mode = Nakama_Discount_Codes::entry_mode( $code );
								$usage_limited = 'yes' === ( isset( $code['usage_limit_enabled'] ) ? $code['usage_limit_enabled'] : 'no' );
								$usage_stats = class_exists( 'Nakama_Discount_Code_Usage' )
									? Nakama_Discount_Code_Usage::stats( $code )
									: array( 'used' => 0, 'reserved' => 0, 'committed' => 0, 'remaining' => null );
								$status_labels = array(
									'active'    => 'Activo ahora',
									'scheduled' => 'Programado',
									'expired'   => 'Expirado',
									'inactive'  => 'Inactivo',
								);
								$field = $codes_opt . '[items][' . $id . ']';
							?>
								<article class="nakama-code-card">
									<div class="nakama-code-card__top">
										<strong><?php echo esc_html( $code['code'] ); ?></strong>
										<span class="nakama-code-status nakama-code-status--<?php echo esc_attr( $status ); ?>">
											<?php echo esc_html( $status_labels[ $status ] ); ?>
										</span>
										<span class="nakama-code-mode"><?php echo self::entry_mode_label( $entry_mode ); ?></span>
									</div>
									<input type="hidden" name="<?php echo esc_attr( $field ); ?>[id]" value="<?php echo esc_attr( $id ); ?>">
									<div class="nakama-code-fields">
										<label>Código
											<input type="text" name="<?php echo esc_attr( $field ); ?>[code]" value="<?php echo esc_attr( $code['code'] ); ?>" pattern="[A-Za-z0-9_-]+" autocomplete="off">
										</label>
										<label>Porcentaje
											<input type="number" name="<?php echo esc_attr( $field ); ?>[percentage]" value="<?php echo esc_attr( round( (float) $code['rate'] * 100, 4 ) ); ?>" min="0.01" max="100" step="0.01">
										</label>
										<label>Inicia
											<input type="date" name="<?php echo esc_attr( $field ); ?>[start]" value="<?php echo esc_attr( $code['start'] ); ?>">
										</label>
										<label>Termina
											<input type="date" name="<?php echo esc_attr( $field ); ?>[end]" value="<?php echo esc_attr( $code['end'] ); ?>">
										</label>
									</div>
									<div class="nakama-code-toggles">
										<label><input type="checkbox" name="<?php echo esc_attr( $field ); ?>[enabled]" <?php checked( 'yes', $code['enabled'] ); ?>> Activo</label>
										<label><input type="checkbox" name="<?php echo esc_attr( $field ); ?>[allow_modifiers]" <?php checked( 'yes', $code['allow_modifiers'] ); ?>> Permitir transferencia, envío gratis y MSI</label>
									</div>
									<fieldset class="nakama-code-usage" data-nakama-usage-limit>
										<legend>Límites de uso</legend>
										<label class="nakama-code-usage__toggle">
											<input type="checkbox" name="<?php echo esc_attr( $field ); ?>[usage_limit_enabled]" <?php checked( true, $usage_limited ); ?> data-nakama-usage-toggle>
											Limitar la cantidad total de usos
										</label>
										<div class="nakama-code-usage__quantity" data-nakama-usage-quantity <?php echo $usage_limited ? '' : 'hidden'; ?>>
											<label>Cantidad máxima de usos
												<input type="number" name="<?php echo esc_attr( $field ); ?>[usage_limit]" value="<?php echo esc_attr( $usage_limited ? (int) $code['usage_limit'] : '' ); ?>" min="<?php echo esc_attr( max( 1, (int) $usage_stats['committed'] ) ); ?>" step="1" inputmode="numeric" <?php echo $usage_limited ? '' : 'disabled'; ?>>
											</label>
										</div>
										<label class="nakama-code-usage__toggle">
											<input type="checkbox" name="<?php echo esc_attr( $field ); ?>[limit_per_customer]" <?php checked( 'yes', isset( $code['limit_per_customer'] ) ? $code['limit_per_customer'] : 'no' ); ?>>
											Permitir solo un uso por cliente
										</label>
										<?php if ( $usage_limited ) : ?>
											<p class="nakama-code-usage__status"><?php echo esc_html( sprintf(
												'%d usados · %d reservados · %d restantes de %d',
												(int) $usage_stats['used'],
												(int) $usage_stats['reserved'],
												(int) $usage_stats['remaining'],
												(int) $code['usage_limit']
											) ); ?></p>
										<?php else : ?>
											<p class="nakama-code-usage__status">Uso ilimitado hasta agotar existencias o hasta que expire el código.</p>
										<?php endif; ?>
									</fieldset>
									<fieldset class="nakama-code-mode-fieldset">
										<legend>¿Cómo podrá usarlo el cliente? <span aria-hidden="true">*</span></legend>
										<label><input type="radio" name="<?php echo esc_attr( $field ); ?>[entry_mode]" value="automatic" <?php checked( Nakama_Discount_Codes::ENTRY_AUTOMATIC, $entry_mode ); ?> required> Mostrar automáticamente</label>
										<label><input type="radio" name="<?php echo esc_attr( $field ); ?>[entry_mode]" value="manual" <?php checked( Nakama_Discount_Codes::ENTRY_MANUAL, $entry_mode ); ?> required> Ingresar código manualmente</label>
									</fieldset>
									<div class="nakama-code-actions">
										<button type="submit" class="button button-secondary">Guardar cambios</button>
										<button
											type="submit"
											class="button-link-delete nakama-code-delete"
											name="<?php echo esc_attr( $field ); ?>[remove]"
											value="yes"
											formnovalidate
											data-nakama-delete-code
											data-code="<?php echo esc_attr( $code['code'] ); ?>"
										>Eliminar código</button>
									</div>
								</article>
							<?php endforeach; ?>
						</div>
					<?php endif; ?>

					<details class="nakama-code-create" data-nakama-create-panel>
						<summary>Crear nuevo código</summary>
						<div class="nakama-code-card nakama-code-card--new">
							<p class="description">Código, porcentaje y modo de uso son obligatorios. Las fechas son opcionales; si las dejas vacías, seguirá vigente hasta que lo desactives.</p>
							<div class="nakama-code-fields">
								<div class="nakama-code-field">
									<label for="nakama-new-code">Código <span aria-hidden="true">*</span></label>
									<input id="nakama-new-code" type="text" name="<?php echo esc_attr( $codes_opt ); ?>[items][new][code]" pattern="[A-Za-z0-9_-]+" autocomplete="off" placeholder="VERANO15" aria-required="true" aria-describedby="nakama-new-code-help nakama-new-code-error" data-nakama-required="code">
									<p id="nakama-new-code-help" class="description">Usa letras, números, guiones o guiones bajos.</p>
									<p id="nakama-new-code-error" class="nakama-field-error" role="alert" data-nakama-field-error="code" hidden></p>
								</div>
								<div class="nakama-code-field">
									<label for="nakama-new-percentage">Porcentaje <span aria-hidden="true">*</span></label>
									<input id="nakama-new-percentage" type="number" name="<?php echo esc_attr( $codes_opt ); ?>[items][new][percentage]" min="0.01" max="100" step="0.01" placeholder="15" aria-required="true" aria-describedby="nakama-new-percentage-help nakama-new-percentage-error" data-nakama-required="percentage">
									<p id="nakama-new-percentage-help" class="description">Ingresa un valor mayor que 0 y hasta 100.</p>
									<p id="nakama-new-percentage-error" class="nakama-field-error" role="alert" data-nakama-field-error="percentage" hidden></p>
								</div>
								<div class="nakama-code-field">
									<label for="nakama-new-start">Inicia</label>
									<input id="nakama-new-start" type="date" name="<?php echo esc_attr( $codes_opt ); ?>[items][new][start]">
								</div>
								<div class="nakama-code-field">
									<label for="nakama-new-end">Termina</label>
									<input id="nakama-new-end" type="date" name="<?php echo esc_attr( $codes_opt ); ?>[items][new][end]">
								</div>
							</div>
							<div class="nakama-code-toggles">
								<label><input type="checkbox" name="<?php echo esc_attr( $codes_opt ); ?>[items][new][enabled]" checked data-nakama-new-enabled> Activo</label>
								<label><input type="checkbox" name="<?php echo esc_attr( $codes_opt ); ?>[items][new][allow_modifiers]" checked> Permitir transferencia, envío gratis y MSI</label>
							</div>
							<fieldset class="nakama-code-usage" data-nakama-usage-limit>
								<legend>Límites de uso</legend>
								<label class="nakama-code-usage__toggle">
									<input type="checkbox" name="<?php echo esc_attr( $codes_opt ); ?>[items][new][usage_limit_enabled]" data-nakama-usage-toggle>
									Limitar la cantidad total de usos
								</label>
								<div class="nakama-code-usage__quantity" data-nakama-usage-quantity hidden>
									<label for="nakama-new-usage-limit">Cantidad máxima de usos <span aria-hidden="true">*</span></label>
									<input id="nakama-new-usage-limit" type="number" name="<?php echo esc_attr( $codes_opt ); ?>[items][new][usage_limit]" min="1" step="1" inputmode="numeric" aria-describedby="nakama-new-usage-limit-help nakama-new-usage-limit-error" data-nakama-required="usage_limit" disabled>
									<p id="nakama-new-usage-limit-help" class="description">Indica un número entero mayor que cero.</p>
									<p id="nakama-new-usage-limit-error" class="nakama-field-error" role="alert" data-nakama-field-error="usage_limit" hidden></p>
								</div>
								<label class="nakama-code-usage__toggle">
									<input type="checkbox" name="<?php echo esc_attr( $codes_opt ); ?>[items][new][limit_per_customer]">
									Permitir solo un uso por cliente
								</label>
								<p class="nakama-code-usage__status">Si no habilitas el límite total, será de uso ilimitado hasta agotar existencias o hasta que expire el código.</p>
							</fieldset>
							<fieldset class="nakama-code-mode-fieldset" data-nakama-entry-mode aria-describedby="nakama-new-entry-mode-help nakama-new-entry-mode-error">
								<legend>¿Cómo podrá usarlo el cliente? <span aria-hidden="true">*</span></legend>
								<label><input type="radio" name="<?php echo esc_attr( $codes_opt ); ?>[items][new][entry_mode]" value="automatic" required> Mostrar automáticamente</label>
								<label><input type="radio" name="<?php echo esc_attr( $codes_opt ); ?>[items][new][entry_mode]" value="manual" required> Ingresar código manualmente</label>
								<p id="nakama-new-entry-mode-help" class="description">El modo automático publica la opción; el manual requiere que el cliente conozca el código.</p>
								<p id="nakama-new-entry-mode-error" class="nakama-field-error" role="alert" data-nakama-entry-mode-error hidden></p>
							</fieldset>
							<div class="nakama-code-actions">
								<button type="submit" class="button button-primary" name="<?php echo esc_attr( $codes_opt ); ?>[items][new][create]" value="yes" formnovalidate data-nakama-create-code>Guardar y activar código</button>
								<button type="button" class="button button-secondary" data-nakama-cancel-create>Cancelar</button>
							</div>
						</div>
					</details>
				</section>

				<!-- ================= CAMPAÑAS ESPECIALES ================= -->
				<div style="background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:18px 20px;margin:16px 0;">
					<h2 style="margin-top:0;">🔥 Campañas especiales</h2>
					<p class="description">Activa o desactiva las promociones especiales. Si defines fechas, la campaña se enciende sola dentro del rango.</p>

					<table class="form-table">
						<tr>
							<th>Especial 10% <br><?php echo self::status_pill( Nakama_Campaigns::special_10_active() ); ?></th>
							<td>
								<label style="font-weight:600;">
									<input type="checkbox" name="<?php echo $opt; ?>[special_10_enabled]" <?php echo $cb('special_10_enabled'); ?>>
									Activar 10% de descuento especial
								</label>
								<p>Agenda opcional:
									desde <input type="date" name="<?php echo $opt; ?>[special_10_start]" value="<?php echo esc_attr($s['special_10_start']); ?>">
									hasta <input type="date" name="<?php echo $opt; ?>[special_10_end]" value="<?php echo esc_attr($s['special_10_end']); ?>">
								</p>
							</td>
						</tr>
						<tr>
							<th>3x2 por categoría <br><?php echo self::status_pill( Nakama_Campaigns::special_3x2_active() ); ?></th>
							<td>
								<label style="font-weight:600;">
									<input type="checkbox" name="<?php echo $opt; ?>[special_3x2_enabled]" <?php echo $cb('special_3x2_enabled'); ?>>
									Activar 3x2 (la prenda gratis es la de menor precio)
								</label>
								<p>Categorías (slugs separados por coma):
									<input type="text" class="regular-text" name="<?php echo $opt; ?>[special_3x2_categories]" value="<?php echo esc_attr( implode( ',', (array) $s['special_3x2_categories'] ) ); ?>">
								</p>
								<p>Agenda opcional:
									desde <input type="date" name="<?php echo $opt; ?>[special_3x2_start]" value="<?php echo esc_attr($s['special_3x2_start']); ?>">
									hasta <input type="date" name="<?php echo $opt; ?>[special_3x2_end]" value="<?php echo esc_attr($s['special_3x2_end']); ?>">
								</p>
							</td>
						</tr>
						<tr>
							<th>Auto-aplicar la mejor</th>
							<td><label><input type="checkbox" name="<?php echo $opt; ?>[special_auto_if_better]" <?php echo $cb('special_auto_if_better'); ?>>
								Aplicar la promo especial sin botón si conviene más que la fidelidad</label></td>
						</tr>
					</table>
				</div>

				<!-- ================= BIENVENIDA / FIDELIDAD ================= -->
				<h2>Bienvenida / Fidelidad (automático)</h2>
				<table class="form-table">
					<tr><th>Activo</th><td><label><input type="checkbox" name="<?php echo $opt; ?>[welcome_enabled]" <?php echo $cb('welcome_enabled'); ?>> Habilitar escalera 5/10/20%</label></td></tr>
					<tr><th>Solo usuarios con cuenta</th><td><label><input type="checkbox" name="<?php echo $opt; ?>[welcome_account_only]" <?php echo $cb('welcome_account_only'); ?>> La fidelidad solo aplica a clientes registrados (recomendado)</label></td></tr>
					<tr><th>Días vigencia 2a compra</th><td><input type="number" name="<?php echo $opt; ?>[welcome_days_2]" value="<?php echo esc_attr($s['welcome_days_2']); ?>"></td></tr>
					<tr><th>Días vigencia 3a compra</th><td><input type="number" name="<?php echo $opt; ?>[welcome_days_3]" value="<?php echo esc_attr($s['welcome_days_3']); ?>"></td></tr>
				</table>

				<!-- ================= AVISO EN MI CUENTA ================= -->
				<h2>Aviso en “Mi Cuenta”</h2>
				<table class="form-table">
					<tr><th>Mostrar aviso</th><td><label><input type="checkbox" name="<?php echo $opt; ?>[account_notice_enabled]" <?php echo $cb('account_notice_enabled'); ?>> Avisar al cliente del descuento disponible y del siguiente nivel</label></td></tr>
					<tr><th>Mensaje al terminar</th><td><label><input type="checkbox" name="<?php echo $opt; ?>[account_notice_complete]" <?php echo $cb('account_notice_complete'); ?>> Mostrar un mensaje de agradecimiento al completar la escalera</label></td></tr>
				</table>

				<!-- ================= MODIFICADORES ================= -->
				<h2>Modificadores</h2>
				<table class="form-table">
					<tr><th>Envío gratis</th><td>
						<label><input type="checkbox" name="<?php echo $opt; ?>[free_ship_enabled]" <?php echo $cb('free_ship_enabled'); ?>> Activar</label>
						desde $<input type="number" step="0.01" name="<?php echo $opt; ?>[free_ship_threshold]" value="<?php echo esc_attr($s['free_ship_threshold']); ?>">
						tope $<input type="number" step="0.01" name="<?php echo $opt; ?>[free_ship_cap]" value="<?php echo esc_attr($s['free_ship_cap']); ?>">
						<p class="description">Overrides por moneda (ej. <code>USD:80</code>, separa con coma):</p>
						umbral: <input type="text" class="regular-text" name="<?php echo $opt; ?>[free_ship_threshold_map]" value="<?php echo esc_attr( Nakama_Settings::currency_map_to_string( $s['free_ship_threshold_map'] ) ); ?>" placeholder="USD:80">
						tope: <input type="text" class="regular-text" name="<?php echo $opt; ?>[free_ship_cap_map]" value="<?php echo esc_attr( Nakama_Settings::currency_map_to_string( $s['free_ship_cap_map'] ) ); ?>" placeholder="USD:8">
					</td></tr>
					<tr><th>Transferencia</th><td>
						<label><input type="checkbox" name="<?php echo $opt; ?>[transfer_enabled]" <?php echo $cb('transfer_enabled'); ?>> Activar</label>
						<input type="number" step="0.01" name="<?php echo $opt; ?>[transfer_rate]" value="<?php echo esc_attr($s['transfer_rate']); ?>"> (0.03 = 3%)
						gateway id: <input type="text" name="<?php echo $opt; ?>[transfer_gateway_id]" value="<?php echo esc_attr($s['transfer_gateway_id']); ?>">
					</td></tr>
					<tr><th>MSI</th><td>
						<label><input type="checkbox" name="<?php echo $opt; ?>[msi_enabled]" <?php echo $cb('msi_enabled'); ?>> Activar</label>
						3 MSI desde $<input type="number" step="0.01" name="<?php echo $opt; ?>[msi_3_threshold]" value="<?php echo esc_attr($s['msi_3_threshold']); ?>">
						6 MSI desde $<input type="number" step="0.01" name="<?php echo $opt; ?>[msi_6_threshold]" value="<?php echo esc_attr($s['msi_6_threshold']); ?>">
						<p class="description">Overrides por moneda (ej. <code>USD:110</code>):</p>
						3 MSI: <input type="text" name="<?php echo $opt; ?>[msi_3_threshold_map]" value="<?php echo esc_attr( Nakama_Settings::currency_map_to_string( $s['msi_3_threshold_map'] ) ); ?>" placeholder="USD:110">
						6 MSI: <input type="text" name="<?php echo $opt; ?>[msi_6_threshold_map]" value="<?php echo esc_attr( Nakama_Settings::currency_map_to_string( $s['msi_6_threshold_map'] ) ); ?>" placeholder="USD:165">
					</td></tr>
				</table>

				<?php submit_button(); ?>
			</form>
			<style>
				.nakama-code-admin { background:#fff; border:1px solid #dcdcde; border-radius:10px; padding:20px; margin:16px 0; }
				.nakama-code-admin h2 { margin:0 0 4px; }
				.nakama-code-empty { padding:14px; background:#f6f7f7; border-radius:8px; }
				.nakama-code-list { display:grid; gap:12px; margin:18px 0; }
				.nakama-code-card { border:1px solid #dcdcde; border-radius:8px; padding:16px; background:#fff; }
				.nakama-code-card--new { margin-top:12px; background:#f6f7f7; }
				.nakama-code-card__top { display:flex; align-items:center; justify-content:space-between; gap:12px; margin-bottom:14px; }
				.nakama-code-card__top strong { font-size:16px; }
				.nakama-code-status { display:inline-flex; align-items:center; min-height:28px; padding:0 10px; border-radius:999px; font-size:12px; font-weight:700; }
				.nakama-code-status--active { background:#dcfce7; color:#166534; }
				.nakama-code-status--scheduled { background:#dbeafe; color:#1e40af; }
				.nakama-code-status--expired, .nakama-code-status--inactive { background:#f3f4f6; color:#4b5563; }
				.nakama-code-mode { display:inline-flex; align-items:center; min-height:28px; padding:0 10px; border-radius:999px; background:#f0f6fc; color:#0a4b78; font-size:12px; font-weight:700; }
				.nakama-code-fields { display:grid; grid-template-columns:2fr 1fr 1fr 1fr; gap:12px; }
				.nakama-code-fields label, .nakama-code-field { display:grid; gap:6px; font-weight:600; }
				.nakama-code-fields input { width:100%; min-height:40px; }
				.nakama-code-field .description { margin:0; font-weight:400; }
				.nakama-field-error { margin:0; color:#b32d2e; font-weight:600; }
				.nakama-code-field input[aria-invalid="true"] { border-color:#b32d2e; box-shadow:0 0 0 1px #b32d2e; }
				.nakama-code-toggles { display:flex; flex-wrap:wrap; gap:12px 22px; margin-top:14px; }
				.nakama-code-toggles label { display:inline-flex; align-items:center; min-height:44px; }
				.nakama-code-usage { display:grid; grid-template-columns:minmax(220px, 1fr) minmax(180px, 260px); gap:10px 22px; margin:14px 0 0; padding:12px; border:1px solid #dcdcde; border-radius:6px; }
				.nakama-code-usage legend { padding:0 6px; font-weight:700; }
				.nakama-code-usage__toggle { display:inline-flex; align-items:center; min-height:44px; }
				.nakama-code-usage__quantity { display:grid; gap:6px; }
				.nakama-code-usage__quantity label { display:grid; gap:6px; font-weight:600; }
				.nakama-code-usage__quantity input { width:100%; min-height:40px; }
				.nakama-code-usage__quantity[hidden] { display:none; }
				.nakama-code-usage__status { grid-column:1 / -1; margin:0; padding:9px 11px; border-left:3px solid #2271b1; background:#f0f6fc; color:#0a4b78; }
				.nakama-code-mode-fieldset { display:flex; flex-wrap:wrap; gap:8px 22px; margin:14px 0 0; padding:12px; border:1px solid #dcdcde; border-radius:6px; }
				.nakama-code-mode-fieldset legend { padding:0 6px; font-weight:700; }
				.nakama-code-mode-fieldset label { display:inline-flex; align-items:center; min-height:44px; }
				.nakama-code-mode-fieldset .description, .nakama-code-mode-fieldset .nakama-field-error { flex-basis:100%; }
				.nakama-code-mode-fieldset[aria-invalid="true"] { border-color:#b32d2e; box-shadow:0 0 0 1px #b32d2e; }
				.nakama-code-actions { display:flex; align-items:center; flex-wrap:wrap; gap:10px; margin-top:16px; }
				.nakama-code-actions .button, .nakama-code-delete { min-height:44px; display:inline-flex; align-items:center; justify-content:center; }
				.nakama-code-delete { color:#b32d2e; cursor:pointer; }
				.nakama-code-create { margin-top:16px; }
				.nakama-code-create summary { display:inline-flex; align-items:center; justify-content:center; min-height:44px; padding:0 16px; border:1px solid #2271b1; border-radius:4px; color:#2271b1; font-weight:600; cursor:pointer; }
				.nakama-code-create summary:focus-visible, .nakama-code-admin input:focus-visible, .nakama-code-admin button:focus-visible { outline:3px solid #72aee6; outline-offset:2px; }
				@media (max-width:900px) { .nakama-code-fields { grid-template-columns:1fr 1fr; } }
				@media (max-width:600px) { .nakama-code-fields, .nakama-code-usage { grid-template-columns:1fr; } }
			</style>
			<script>
				(function () {
					var root = document.currentScript.closest('.wrap');
					var form = root.querySelector('form');
					var panel = root.querySelector('[data-nakama-create-panel]');
					var createButton = root.querySelector('[data-nakama-create-code]');
					var cancelButton = root.querySelector('[data-nakama-cancel-create]');
					var enabledInput = root.querySelector('[data-nakama-new-enabled]');
					var modeGroup = panel.querySelector('[data-nakama-entry-mode]');
					var modeRadios = modeGroup.querySelectorAll('input[type="radio"]');
					var modeError = modeGroup.querySelector('[data-nakama-entry-mode-error]');
					var usageGroups = root.querySelectorAll('[data-nakama-usage-limit]');
					var newUsageGroup = panel.querySelector('[data-nakama-usage-limit]');
					var newUsageToggle = newUsageGroup.querySelector('[data-nakama-usage-toggle]');
					var newUsageInput = newUsageGroup.querySelector('[data-nakama-required="usage_limit"]');

					function syncUsageLimit(group) {
						var toggle = group.querySelector('[data-nakama-usage-toggle]');
						var quantity = group.querySelector('[data-nakama-usage-quantity]');
						var input = quantity.querySelector('input[type="number"]');
						quantity.hidden = !toggle.checked;
						input.disabled = !toggle.checked;
						if (!toggle.checked && input.getAttribute('aria-invalid') === 'true' && group === newUsageGroup) {
							clearFieldError(input);
						}
					}

					function showFieldError(field, message) {
						var error = panel.querySelector('[data-nakama-field-error="' + field.dataset.nakamaRequired + '"]');
						field.setAttribute('aria-invalid', 'true');
						error.textContent = message;
						error.hidden = false;
					}

					function clearFieldError(field) {
						var error = panel.querySelector('[data-nakama-field-error="' + field.dataset.nakamaRequired + '"]');
						field.removeAttribute('aria-invalid');
						error.textContent = '';
						error.hidden = true;
					}

					function showModeError(message) {
						modeGroup.setAttribute('aria-invalid', 'true');
						modeError.textContent = message;
						modeError.hidden = false;
					}

					function clearModeError() {
						modeGroup.removeAttribute('aria-invalid');
						modeError.textContent = '';
						modeError.hidden = true;
					}

					function validateCreation() {
						var code = panel.querySelector('[data-nakama-required="code"]');
						var percentage = panel.querySelector('[data-nakama-required="percentage"]');
						var firstInvalid = null;
						var codeValue = code.value.trim();
						var percentageValue = percentage.value.trim();
						var numericPercentage = Number(percentageValue);
						var selectedMode = panel.querySelector('[data-nakama-entry-mode] input[type="radio"]:checked');
						var usageLimitValue = newUsageInput.value.trim();
						var numericUsageLimit = Number(usageLimitValue);

						clearFieldError(code);
						clearFieldError(percentage);
						clearFieldError(newUsageInput);
						clearModeError();
						if (!codeValue) {
							showFieldError(code, 'Escribe el código que verá el cliente.');
							firstInvalid = code;
						} else if (!/^[A-Za-z0-9_-]+$/.test(codeValue)) {
							showFieldError(code, 'Usa solo letras, números, guiones o guiones bajos.');
							firstInvalid = code;
						}
						if (!percentageValue) {
							showFieldError(percentage, 'Indica el porcentaje de descuento.');
							firstInvalid = firstInvalid || percentage;
						} else if (!Number.isFinite(numericPercentage) || numericPercentage <= 0 || numericPercentage > 100) {
							showFieldError(percentage, 'Ingresa un porcentaje mayor que 0 y hasta 100.');
							firstInvalid = firstInvalid || percentage;
						}
						if (!selectedMode) {
							showModeError('Elige si el código se mostrará automáticamente o se ingresará manualmente.');
							firstInvalid = firstInvalid || modeRadios[0];
						}
						if (newUsageToggle.checked && (!usageLimitValue || !Number.isInteger(numericUsageLimit) || numericUsageLimit <= 0)) {
							showFieldError(newUsageInput, 'Indica una cantidad de usos mayor que cero.');
							firstInvalid = firstInvalid || newUsageInput;
						}

						if (firstInvalid) {
							panel.open = true;
							firstInvalid.focus();
							return false;
						}
						return true;
					}

					function updateCreateLabel() {
						createButton.textContent = enabledInput.checked
							? 'Guardar y activar código'
							: 'Guardar código inactivo';
					}

					form.addEventListener('submit', function (event) {
						var submitter = event.submitter;
						if (submitter && submitter.matches('[data-nakama-delete-code]')) {
							var code = submitter.dataset.code || 'este código';
							if (!window.confirm('¿Eliminar ' + code + '? Dejará de aparecer en checkout; los pedidos anteriores no cambian.')) {
								event.preventDefault();
							}
							return;
						}
						if (submitter && submitter.matches('[data-nakama-create-code]') && !validateCreation()) {
							event.preventDefault();
						}
					});

					panel.querySelectorAll('[data-nakama-required]').forEach(function (field) {
						field.addEventListener('input', function () {
							if (field.getAttribute('aria-invalid') === 'true') {
								clearFieldError(field);
							}
						});
					});
					modeRadios.forEach(function (field) {
						field.addEventListener('change', clearModeError);
					});
					usageGroups.forEach(function (group) {
						var toggle = group.querySelector('[data-nakama-usage-toggle]');
						toggle.addEventListener('change', function () { syncUsageLimit(group); });
						syncUsageLimit(group);
					});

					cancelButton.addEventListener('click', function () {
						panel.querySelectorAll('input').forEach(function (field) {
							if (field.type === 'checkbox' || field.type === 'radio') {
								field.checked = field.defaultChecked;
							} else {
								field.value = '';
							}
							if (field.dataset.nakamaRequired) {
								clearFieldError(field);
							}
						});
						clearModeError();
						usageGroups.forEach(syncUsageLimit);
						updateCreateLabel();
						panel.open = false;
						panel.querySelector('summary').focus();
					});

					enabledInput.addEventListener('change', updateCreateLabel);
					updateCreateLabel();
				})();
			</script>
		</div>
		<?php
	}
}
