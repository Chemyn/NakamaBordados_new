<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * EL CEREBRO.
 * Recibe un Nakama_Context y devuelve un "plan" de descuento consistente con
 * todas las reglas de combinación.
 *
 * Estructura del plan:
 * [
 *   'primary'    => null | ['type'=>..,'label'=>..,'amount'=>float,'free_items'=>[]],
 *   'options'    => [ opciones primarias elegibles -> botones ],
 *   'transfer'   => ['applies'=>bool,'amount'=>float],
 *   'free_ship'  => bool,
 *   'msi'        => ['months'=>0|3|6],
 *   'totals'     => [
 *     'subtotal'=>..,'after_primary'=>..,'final'=>..,
 *     'eligible_subtotal'=>..,'eligible_after_primary'=>..,'eligible_final'=>..
 *   ],
 * ]
 */
class Nakama_Engine {

	public static function resolve( Nakama_Context $ctx ) {
		$subtotal          = $ctx->subtotal;
		$eligible_subtotal = $ctx->eligible_subtotal;

		// 1) Construir candidatos PRIMARIOS (grupo mutuamente excluyente A/B/C).
		$candidates = self::build_primary_candidates( $ctx );

		// 2) Elegir UNA primaria. Un cupón nativo (recuperación de carrito)
		// ocupa el mismo lugar y por ello suspende cualquier primaria Nakama.
		$has_native_coupon = ! empty( $ctx->native_coupon_codes );
		$selection_valid = ! $ctx->selected_promo || isset( $candidates[ $ctx->selected_promo ] );
		$primary = $has_native_coupon ? null : self::choose_primary( $candidates, $ctx );

		$primary_amount       = $primary ? $primary['amount'] : 0.0;
		$native_coupon_amount = $has_native_coupon ? max( 0, (float) $ctx->native_coupon_amount ) : 0.0;
		$after_primary        = max( 0, $subtotal - $primary_amount - $native_coupon_amount );
		$eligible_after_primary = max( 0, $eligible_subtotal - $primary_amount - $native_coupon_amount );
		// Every extension uses the same explicit combination contract. Historic
		// candidates that omit the key preserve their previous combinable behavior.
		$allows_modifiers = ! $primary
			|| ! array_key_exists( 'allow_modifiers', $primary )
			|| ! empty( $primary['allow_modifiers'] );

		// 3) Modificador E: transferencia (3% sobre subtotal ya descontado).
		$transfer = array( 'applies' => false, 'amount' => 0.0 );
		if ( $allows_modifiers
			&& $eligible_after_primary > 0
			&& 'yes' === Nakama_Settings::get( 'transfer_enabled' )
			&& $ctx->payment_method === Nakama_Settings::get( 'transfer_gateway_id' ) ) {
			$rate               = (float) Nakama_Settings::get( 'transfer_rate' );
			$transfer['applies'] = true;
			$transfer['amount']  = round( $eligible_after_primary * $rate, 2 );
		}

		$final          = max( 0, $after_primary - $transfer['amount'] );
		$eligible_final = max( 0, $eligible_after_primary - $transfer['amount'] );

		// 4) Modificador D: envío gratis (usa total DESPUÉS de descuentos).
		$free_ship = false;
		if ( $allows_modifiers && 'yes' === Nakama_Settings::get( 'free_ship_enabled' ) ) {
			$threshold = Nakama_Settings::amount( 'free_ship_threshold' );
			$free_ship = $eligible_final >= $threshold;
		}

		// 5) Modificador F: MSI.
		$msi_months = $allows_modifiers ? self::resolve_msi( $eligible_final ) : 0;

		return array(
			'primary'   => $primary,
			'options'   => $candidates, // para pintar botones
			'selection_valid' => $selection_valid,
			'native_coupon' => array(
				'applies' => $has_native_coupon,
				'codes'   => $has_native_coupon ? $ctx->native_coupon_codes : array(),
				'amount'  => $native_coupon_amount,
			),
			'allows_modifiers' => $allows_modifiers,
			'transfer'  => $transfer,
			'free_ship' => $free_ship,
			'msi'       => array( 'months' => $msi_months ),
			'totals'    => array(
				'subtotal'      => $subtotal,
				'after_primary' => $after_primary,
				'final'                  => $final,
				'eligible_subtotal'      => $eligible_subtotal,
				'eligible_after_primary' => $eligible_after_primary,
				'eligible_final'         => $eligible_final,
			),
		);
	}

	/**
	 * Devuelve TODAS las promos primarias para las que el cliente/carrito
	 * califica en este momento. Solo una se aplicará (choose_primary).
	 */
	private static function build_primary_candidates( Nakama_Context $ctx ) {
		$out      = array();
		$subtotal = $ctx->eligible_subtotal;

		// A) Bienvenida / Fidelidad.
		$tier = Nakama_Customer_History::get_welcome_tier( $ctx->customer_id, $ctx->email );
		if ( $tier && $subtotal > 0 ) {
			$out['welcome'] = array(
				'type'       => 'welcome',
				'label'      => $tier['label'],
				'rate'       => $tier['rate'],
				'amount'     => round( $subtotal * $tier['rate'], 2 ),
				'free_items' => array(),
				'auto'       => true, // se aplica sin botón
			);
		}

		// B) Especial 10%.
		if ( $subtotal > 0 && Nakama_Campaigns::special_10_active() ) {
			$rate = (float) Nakama_Settings::get( 'special_10_rate' );
			$out['special_10'] = array(
				'type'       => 'special_10',
				'label'      => 'Descuento especial 10%',
				'rate'       => $rate,
				'amount'     => round( $subtotal * $rate, 2 ),
				'free_items' => array(),
				'auto'       => false, // requiere botón
			);
		}

		// C) 3x2 por categoría.
		if ( Nakama_Campaigns::special_3x2_active() ) {
			$free = self::calc_3x2( $ctx->threexthree_prices );
			if ( $free['count'] > 0 ) {
				$out['special_3x2'] = array(
					'type'       => 'special_3x2',
					'label'      => sprintf( '3x2 (%d gratis)', $free['count'] ),
					'rate'       => 0,
					'amount'     => $free['amount'],
					'free_items' => $free['items'],
					'auto'       => false,
				);
			}
		}

		// D) Códigos públicos creados desde Nakama Descuentos. Son opciones
		// visibles y nunca se registran como cupones nativos de WooCommerce.
		if ( $subtotal > 0 ) {
			foreach ( Nakama_Discount_Codes::active() as $id => $code ) {
				$entry_mode = Nakama_Discount_Codes::entry_mode( $code );
				if (
					Nakama_Discount_Codes::ENTRY_MANUAL === $entry_mode
					&& sanitize_key( $id ) !== sanitize_key( $ctx->unlocked_public_code_id )
				) {
					continue;
				}
				$rate = isset( $code['rate'] ) ? (float) $code['rate'] : 0.0;
				if ( $rate <= 0 ) {
					continue;
				}
				$key = Nakama_Discount_Codes::selection_key( $id );
				$out[ $key ] = array(
					'type'            => 'public_code',
					'selection_key'   => $key,
					'id'              => isset( $code['id'] ) ? $code['id'] : $id,
					'code'            => isset( $code['code'] ) ? $code['code'] : '',
					'label'           => sprintf(
						/* translators: 1: public code, 2: percentage */
						__( 'Código %1$s (%2$s)', 'nakama-discounts' ),
						isset( $code['code'] ) ? $code['code'] : '',
						Nakama_Settings::pct( $rate )
					),
					'rate'            => $rate,
					'amount'          => round( $subtotal * $rate, 2 ),
					'free_items'      => array(),
					'auto'            => false,
					'allow_modifiers' => 'yes' === ( isset( $code['allow_modifiers'] ) ? $code['allow_modifiers'] : 'no' ),
					'entry_mode'      => $entry_mode,
				);
			}
		}

		/**
		 * Add trusted, server-side primary candidates without coupling this engine
		 * to their storage. Browser input is never passed through this filter.
		 *
		 * @param array          $out Eligible candidates keyed by selection key.
		 * @param Nakama_Context $ctx Authoritative cart context.
		 */
		$out = apply_filters( 'nakama_discount_primary_candidates', $out, $ctx );
		$selected = (string) $ctx->selected_promo;
		if (
			$selected
			&& isset( $out[ $selected ] )
			&& 'public_code' === ( isset( $out[ $selected ]['type'] ) ? $out[ $selected ]['type'] : '' )
			&& Nakama_Discount_Codes::ENTRY_MANUAL === ( isset( $out[ $selected ]['entry_mode'] ) ? $out[ $selected ]['entry_mode'] : '' )
			&& empty( $out[ $selected ]['allow_modifiers'] )
		) {
			return array( $selected => $out[ $selected ] );
		}

		return $out;
	}

	/**
	 * Reglas de exclusividad ya están garantizadas: A/B/C nunca se apilan.
	 * Selección:
	 *   - Si el cliente eligió una por botón y sigue elegible -> esa.
	 *   - Si no, se aplica la 'welcome' (automática) si existe.
	 *   - Si 'special_auto_if_better' = yes, se aplica la de mayor valor.
	 */
	private static function choose_primary( array $candidates, Nakama_Context $ctx ) {
		if ( empty( $candidates ) ) {
			return null;
		}

		$selected = $ctx->selected_promo;
		if ( $selected && isset( $candidates[ $selected ] ) ) {
			return $candidates[ $selected ];
		}

		if ( 'yes' === Nakama_Settings::get( 'special_auto_if_better' ) ) {
			$automatic_candidates = array_filter( $candidates, function ( $candidate ) {
				// Any candidate marked as opt-in (including extensions) requires an
				// explicit customer/server selection.
				return ! empty( $candidate['auto'] );
			} );
			uasort( $automatic_candidates, function ( $a, $b ) {
				return $b['amount'] <=> $a['amount'];
			} );
			if ( ! empty( $automatic_candidates ) ) {
				return reset( $automatic_candidates );
			}
		}

		// Default: bienvenida es automática; las especiales requieren botón.
		if ( isset( $candidates['welcome'] ) ) {
			return $candidates['welcome'];
		}

		return null; // hay especiales disponibles pero el cliente no ha elegido
	}

	/**
	 * 3x2 COMBINADO: se cuentan juntos todos los ítems de las categorías
	 * habilitadas. Por cada 3 unidades en total, 1 gratis. Las prendas gratis
	 * son SIEMPRE las de menor precio del conjunto completo.
	 * Ej.: 2 gorras + 1 bordado = 3 -> 1 gratis (la más barata de las tres).
	 * @return array ['count'=>int,'amount'=>float,'items'=>float[]]
	 */
	private static function calc_3x2( array $prices ) {
		sort( $prices ); // menor -> mayor (sobre la bolsa combinada)
		$qty      = count( $prices );
		$free_qty = intdiv( $qty, 3 ); // 3->1, 4/5->1, 6->2, ...

		$amount = 0.0;
		$items  = array();
		for ( $i = 0; $i < $free_qty; $i++ ) {
			$amount  += $prices[ $i ]; // las más baratas del total
			$items[]  = $prices[ $i ];
		}

		return array(
			'count'  => $free_qty,
			'amount' => round( $amount, 2 ),
			'items'  => $items,
		);
	}

	private static function resolve_msi( $final_total ) {
		if ( 'yes' !== Nakama_Settings::get( 'msi_enabled' ) ) {
			return 0;
		}
		$t3 = Nakama_Settings::amount( 'msi_3_threshold' );
		$t6 = Nakama_Settings::amount( 'msi_6_threshold' );

		// 6 MSI solo durante campaña especial.
		if ( Nakama_Campaigns::any_special_active() && $final_total >= $t6 ) {
			return 6;
		}
		if ( $final_total >= $t3 ) {
			return 3;
		}
		return 0;
	}
}
