<?php
/**
 * Plugin Name: Nakama Products API
 * Description: API REST pública y RÁPIDA de productos (WooCommerce/$wpdb directo, sin WPGraphQL) para el frontend estático de Next.js.
 * Version: 1.9
 * Author: Nakama
 */

if (!defined('ABSPATH')) {
    exit; // Salir si se accede directamente.
}

// Se incluye en las claves de caché: al actualizar el plugin (nuevo shape de
// respuesta, p. ej. regularPrice en 1.8) los transients viejos quedan huérfanos
// en lugar de servirse 15 minutos con el formato anterior.
define('NAKAMA_PRODUCTS_API_VER', '1.9');

// Semilla one-time del contador de folios: deja el contador en 11 para que el
// PRIMER folio emitido por /next-folio sea NK-12. Va protegida por un flag para
// que se ejecute UNA sola vez y NO se repita en cada request ni en cada
// despliegue (el contador es una opción de WordPress y persiste por sí solo;
// los builds del frontend no lo tocan). No retrocede folios ya emitidos porque
// tras la semilla el flag impide volver a correr.
add_action('init', function () {
    if (get_option('nakama_folio_seed_v12') !== 'done') {
        update_option('nakama_quote_folio_counter', 11);
        update_option('nakama_folio_seed_v12', 'done');
    }
});

// Evitar errores fatales si WooCommerce no está activo
if (!class_exists('WooCommerce') && !in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
    return;
}

/**
 * ATRIBUTOS DE VARIACIÓN DE ESTA TIENDA
 * WooCommerce guarda los atributos globales como taxonomías con prefijo `pa_`.
 * El frontend espera las claves capitalizadas (Color / Estilo / Talla).
 * Este mapa traduce las taxonomías internas -> claves que consume el TS.
 */
function nakama_products_attribute_key_map()
{
    return array(
        'pa_color' => 'Color',
        'pa_estilo' => 'Estilo',
        'pa_talla' => 'Talla',
    );
}

/**
 * Convierte el nombre técnico de un atributo (ej. "pa_color", "attribute_pa_color",
 * "Color") a la clave capitalizada que espera el frontend.
 */
function nakama_products_normalize_attribute_key($raw_key)
{
    $map = nakama_products_attribute_key_map();

    // Normalizar: quitar prefijo "attribute_" que usan las meta de variación.
    $key = str_replace('attribute_', '', (string) $raw_key);
    $key = strtolower($key);

    if (isset($map[$key])) {
        return $map[$key];
    }

    // Atributo no global o personalizado: capitalizar de forma legible.
    $clean = str_replace('pa_', '', $key);
    $clean = str_replace(array('-', '_'), ' ', $clean);
    return ucwords($clean);
}

/**
 * Añade cabeceras CORS estándar a una respuesta REST (frontend estático).
 */
function nakama_products_add_cors($response)
{
    $response->header('Access-Control-Allow-Origin', '*');
    $response->header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    $response->header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    // Evitar que LiteSpeed cachee respuestas del API: una respuesta vacía
    // cacheada dejaba categorías enteras "sin productos" hasta purgar.
    $response->header('X-LiteSpeed-Cache-Control', 'no-cache');
    $response->header('Cache-Control', 'no-cache, must-revalidate, max-age=0');
    return $response;
}

/**
 * Handler del preflight OPTIONS (CORS) compartido por los endpoints públicos.
 */
function nakama_products_preflight()
{
    return nakama_products_add_cors(rest_ensure_response(null));
}

// ============================================================================
// CACHÉ DE RESPUESTAS (transients)
// ============================================================================
// Construir cada respuesta ejecuta cientos de consultas (términos, imágenes y
// variaciones por producto) y las cabeceras no-cache — necesarias por el bug
// de respuestas vacías cacheadas en LiteSpeed — hacen que CADA visita pague
// ese costo completo: la carga de productos era muy lenta. El caché vive en
// transients del servidor (la BD responde en ms) y se invalida al instante
// cuando se guarda un producto, así que no reintroduce el problema de datos
// viejos que tenía LiteSpeed.

/** Sello de versión del caché: cambia cuando se edita/guarda un producto. */
function nakama_products_cache_version()
{
    return (string) get_option('nakama_products_cache_ver', '1');
}

/** Invalida TODO el caché de productos (las claves viejas expiran solas). */
function nakama_products_bump_cache()
{
    update_option('nakama_products_cache_ver', (string) microtime(true), false);
}

// Cualquier cambio relevante invalida: guardar/editar producto o stock,
// registrar ventas (afecta el orden de "más vendidos") y aprobar reseñas.
add_action('save_post_product', 'nakama_products_bump_cache');
add_action('woocommerce_update_product', 'nakama_products_bump_cache');
add_action('woocommerce_product_set_stock', 'nakama_products_bump_cache');
add_action('woocommerce_variation_set_stock', 'nakama_products_bump_cache');
add_action('woocommerce_recorded_sales', 'nakama_products_bump_cache');
add_action('transition_comment_status', 'nakama_products_bump_cache');
add_action('wp_insert_comment', 'nakama_products_bump_cache');

/** Clave de transient estable para un conjunto de parámetros. */
function nakama_products_cache_key($prefix, $parts)
{
    $parts[] = nakama_products_cache_version();
    $parts[] = NAKAMA_PRODUCTS_API_VER;
    return $prefix . '_' . md5(wp_json_encode($parts));
}

// ============================================================================
// REGISTRO DE RUTAS REST
// ============================================================================
add_action('rest_api_init', function () {

    // 1) Listado / búsqueda / paginación de productos.
    //    URL: https://nakamabordados.com/wp-json/nakama/v1/products
    register_rest_route('nakama/v1', '/products', array(
        array(
            'methods' => 'GET',
            'callback' => 'nakama_products_list',
            'permission_callback' => '__return_true', // Lectura pública.
        ),
        array(
            'methods' => 'OPTIONS',
            'callback' => 'nakama_products_preflight',
            'permission_callback' => '__return_true',
        ),
    ));

    // 2) Producto único (por slug), con variaciones.
    //    URL: https://nakamabordados.com/wp-json/nakama/v1/product?slug=<slug>
    register_rest_route('nakama/v1', '/product', array(
        array(
            'methods' => 'GET',
            'callback' => 'nakama_products_single',
            'permission_callback' => '__return_true',
        ),
        array(
            'methods' => 'OPTIONS',
            'callback' => 'nakama_products_preflight',
            'permission_callback' => '__return_true',
        ),
    ));

    // 3) Lista ligera de TODOS los slugs publicados (para generar rutas en build).
    //    URL: https://nakamabordados.com/wp-json/nakama/v1/product-slugs
    register_rest_route('nakama/v1', '/product-slugs', array(
        array(
            'methods' => 'GET',
            'callback' => 'nakama_products_slugs',
            'permission_callback' => '__return_true',
        ),
        array(
            'methods' => 'OPTIONS',
            'callback' => 'nakama_products_preflight',
            'permission_callback' => '__return_true',
        ),
    ));

    // 4) Modo Mantenimiento GET/POST/OPTIONS
    register_rest_route('nakama/v1', '/maintenance', array(
        array(
            'methods' => 'GET',
            'callback' => 'nakama_get_maintenance_status',
            'permission_callback' => '__return_true',
        ),
        array(
            'methods' => 'POST',
            'callback' => 'nakama_set_maintenance_status',
            'permission_callback' => function () {
                return current_user_can('manage_options');
            },
        ),
        array(
            'methods' => 'OPTIONS',
            'callback' => 'nakama_products_preflight',
            'permission_callback' => '__return_true',
        ),
    ));

    // 5) Folio de cotización incremental
    register_rest_route('nakama/v1', '/next-folio', array(
        array(
            'methods' => array('GET', 'POST'),
            'callback' => 'nakama_products_get_next_folio',
            'permission_callback' => '__return_true',
        ),
        array(
            'methods' => 'OPTIONS',
            'callback' => 'nakama_products_preflight',
            'permission_callback' => '__return_true',
        ),
    ));

    // 6) Enviar valoración/reseña
    register_rest_route('nakama/v1', '/submit-review', array(
        array(
            'methods' => 'POST',
            'callback' => 'nakama_products_submit_review',
            'permission_callback' => '__return_true',
        ),
        array(
            'methods' => 'OPTIONS',
            'callback' => 'nakama_products_preflight',
            'permission_callback' => '__return_true',
        ),
    ));
});

function nakama_products_get_next_folio()
{
    // Default 11 => el primer folio es NK-12 (coincide con la semilla de arriba
    // para instalaciones nuevas donde la opción aún no existe).
    $current_folio = (int) get_option('nakama_quote_folio_counter', 11);
    $next_folio = $current_folio + 1;
    update_option('nakama_quote_folio_counter', $next_folio);
    
    $response = rest_ensure_response(array(
        'success' => true,
        'folio' => $next_folio,
        'formatted' => 'NK-' . $next_folio
    ));
    return nakama_products_add_cors($response);
}

function nakama_products_submit_review($request)
{
    $params = $request->get_json_params();
    if (empty($params)) {
        $params = $request->get_body_params();
    }

    $product_id = isset($params['product_id']) ? (int)$params['product_id'] : 0;
    $author_name = isset($params['name']) ? sanitize_text_field($params['name']) : '';
    $author_email = isset($params['email']) ? sanitize_email($params['email']) : '';
    $comment = isset($params['comment']) ? sanitize_textarea_field($params['comment']) : '';
    $rating = isset($params['rating']) ? (int)$params['rating'] : 5;

    if ($product_id <= 0 || empty($author_name) || empty($author_email) || empty($comment)) {
        $response = new WP_Error('missing_fields', 'Faltan campos obligatorios para la valoración.', array('status' => 400));
        return nakama_products_add_cors(rest_ensure_response($response));
    }

    $commentdata = array(
        'comment_post_ID' => $product_id,
        'comment_author' => $author_name,
        'comment_author_email' => $author_email,
        'comment_content' => $comment,
        'comment_type' => 'review',
        'comment_approved' => 0, // Requiere aprobación manual
    );

    $comment_id = wp_insert_comment($commentdata);
    if ($comment_id) {
        update_comment_meta($comment_id, 'rating', $rating);
        $response = rest_ensure_response(array(
            'success' => true,
            'message' => 'Valoración enviada correctamente. Será visible una vez aprobada.'
        ));
        return nakama_products_add_cors($response);
    }

    $response = new WP_Error('insert_failed', 'No se pudo guardar la valoración.', array('status' => 500));
    return nakama_products_add_cors(rest_ensure_response($response));
}

// ============================================================================
// CONSTRUCTORES DE OBJETOS (mapean WC_Product -> shape del frontend)
// ============================================================================

/**
 * Construye un objeto Variation a partir de un WC_Product_Variation.
 * Coincide con el tipo `Variation` de src/types/product.ts.
 */
function nakama_products_build_variation($variation)
{
    if (!$variation instanceof WC_Product) {
        return null;
    }

    $variation_id = $variation->get_id();

    // SKU: usar el de WC o generar uno estable "WP-VAR-<id>".
    $sku = $variation->get_sku();
    if (empty($sku)) {
        $sku = 'WP-VAR-' . $variation_id;
    }

    // Precio numérico actual (WC ya resuelve oferta vs regular en get_price())
    // y precio regular para poder mostrar el descuento tachado en el frontend.
    $price = (float) $variation->get_price();
    $regular_price = (float) $variation->get_regular_price();

    // Imagen específica de la variación (si tiene), si no [].
    $images = array();
    $image_id = $variation->get_image_id();
    if ($image_id) {
        $url = wp_get_attachment_url($image_id);
        if ($url) {
            $images[] = $url;
        }
    }

    // Atributos: get_attributes() devuelve [ 'pa_color' => 'rojo', ... ] (valores = slug del término).
    $attributes = array();
    foreach ($variation->get_attributes() as $attr_key => $attr_value) {
        if ('' === $attr_value || null === $attr_value) {
            continue;
        }

        $label_key = nakama_products_normalize_attribute_key($attr_key);

        // Si es taxonomía global, convertir el slug del término a su nombre legible.
        $display_value = $attr_value;
        if (taxonomy_exists($attr_key)) {
            $term = get_term_by('slug', $attr_value, $attr_key);
            if ($term && !is_wp_error($term)) {
                $display_value = $term->name;
            }
        }

        $attributes[$label_key] = wp_specialchars_decode($display_value);
    }

    // Stock: cantidad o 0.
    $stock = $variation->get_stock_quantity();
    $stock = (null === $stock) ? 0 : (int) $stock;

    return array(
        'id' => (string) $variation_id,
        'databaseId' => (int) $variation_id,
        'sku' => $sku,
        'price' => $price,
        'regularPrice' => $regular_price,
        'images' => $images,
        'attributes' => (object) $attributes, // objeto JSON, no array, incluso vacío.
        'stock' => $stock,
    );
}

/**
 * Construye un objeto Product completo a partir de un WC_Product.
 * Coincide con el tipo `Product` de src/types/product.ts.
 *
 * $light = true (listados): omite descripción y reseñas — las tarjetas de la
 * tienda/sliders no las usan y get_comments por producto encarecía cada
 * listado. El detalle del producto (endpoint /product) siempre va completo.
 */
function nakama_products_build_product($product, $light = false)
{
    if (!$product instanceof WC_Product) {
        return null;
    }

    $database_id = $product->get_id();

    // id = slug (post_name); identificador primario usado en /product/<id>.
    $slug = $product->get_slug();

    // SKU: WC o "WP-<id>".
    $sku = $product->get_sku();
    if (empty($sku)) {
        $sku = 'WP-' . $database_id;
    }

    // Precio numérico actual (oferta si aplica, si no regular) y precio
    // regular para el tachado de descuentos. En variables, el regular del
    // rango más barato (las tarjetas muestran "desde" el precio mínimo).
    $price = (float) $product->get_price();
    if ($product->is_type('variable') && method_exists($product, 'get_variation_regular_price')) {
        $regular_price = (float) $product->get_variation_regular_price('min');
    } else {
        $regular_price = (float) $product->get_regular_price();
    }

    // Categorías -> array de SLUGS.
    $categories = wp_get_post_terms($database_id, 'product_cat', array('fields' => 'slugs'));
    if (is_wp_error($categories)) {
        $categories = array();
    }

    // Tags -> array de NOMBRES.
    $tags = wp_get_post_terms($database_id, 'product_tag', array('fields' => 'names'));
    if (is_wp_error($tags)) {
        $tags = array();
    }

    // Imágenes: destacada primero, luego galería.
    $images = array();
    $featured_id = $product->get_image_id();
    if ($featured_id) {
        $url = wp_get_attachment_url($featured_id);
        if ($url) {
            $images[] = $url;
        }
    }
    foreach ($product->get_gallery_image_ids() as $gallery_id) {
        $url = wp_get_attachment_url($gallery_id);
        if ($url) {
            $images[] = $url;
        }
    }

    // Tipo: 'variable' o 'simple' (cualquier otro tipo se trata como simple para el frontend).
    $type = $product->is_type('variable') ? 'variable' : 'simple';

    // Variaciones: [] para simples; para variables recorrer los hijos.
    $variations = array();
    if ('variable' === $type) {
        foreach ($product->get_children() as $child_id) {
            $child = wc_get_product($child_id);
            $built = nakama_products_build_variation($child);
            if ($built) {
                $variations[] = $built;
            }
        }
    }

    // Rating: promedio de WC o 5 si no hay reseñas.
    $rating = (float) $product->get_average_rating();
    if ($rating <= 0) {
        $rating = 5;
    }

    // Ventas: total_sales o número pseudoaleatorio estable entre 1 y 10 (basado en el ID de la base de datos).
    $sales_count = (int) $product->get_total_sales();
    if ($sales_count <= 0) {
        $sales_count = (($database_id * 7) % 10) + 1;
    }

    // Obtener valoraciones reales de WooCommerce (solo en modo completo).
    $reviews = array();
    $comments = $light ? array() : get_comments(array(
        'post_id' => $database_id,
        'status' => 'approve',
        'type' => 'review'
    ));

    if (!empty($comments) && !is_wp_error($comments)) {
        foreach ($comments as $comment) {
            $review_rating = (int) get_comment_meta($comment->comment_ID, 'rating', true);
            if ($review_rating <= 0) {
                $review_rating = 5;
            }
            
            $review_date = human_time_diff(get_comment_date('U', $comment->comment_ID), current_time('timestamp'));
            
            $reviews[] = array(
                'id' => (string) $comment->comment_ID,
                'name' => esc_html($comment->comment_author),
                'rating' => $review_rating,
                'comment' => esc_html($comment->comment_content),
                'date' => sprintf('Hace %s', $review_date)
            );
        }
    }

    return array(
        'id' => (string) $slug,
        'databaseId' => (int) $database_id,
        'name' => wp_specialchars_decode($product->get_name()),
        'sku' => $sku,
        'price' => $price,
        'regularPrice' => $regular_price,
        'description' => $light ? '' : $product->get_description(), // HTML permitido.
        'categories' => array_values($categories),
        'tags' => array_values($tags),
        'images' => $images,
        'type' => $type,
        'variations' => $variations,
        'rating' => $rating,
        'salesCount' => $sales_count,
        'reviews' => $reviews,
    );
}

// ============================================================================
// 1) HANDLER: LISTADO / BÚSQUEDA / PAGINACIÓN
// ============================================================================
function nakama_products_list($request)
{
    // Sanitizar parámetros de entrada.
    $limit = absint($request->get_param('limit'));
    $offset = absint($request->get_param('offset'));
    $category = sanitize_text_field((string) $request->get_param('category'));
    $tag = sanitize_text_field((string) $request->get_param('tag'));
    $search = sanitize_text_field((string) $request->get_param('search'));
    $orderby = sanitize_text_field((string) $request->get_param('orderby'));

    if ($limit <= 0) {
        $limit = 20; // Por defecto.
    }
    // offset ya es >= 0 gracias a absint().

    // Caché servidor: la misma consulta se sirve desde transient hasta que un
    // producto cambie (ver nakama_products_bump_cache).
    $cache_key = nakama_products_cache_key('nkp_list', array($limit, $offset, $category, $tag, $search, $orderby));
    $cached = get_transient($cache_key);
    if (false !== $cached && is_array($cached)) {
        return nakama_products_add_cors(rest_ensure_response($cached));
    }

    // Construir argumentos para wc_get_products (devuelve precios/variaciones correctos).
    // Pedimos limit+1 para saber si hay página siguiente sin un COUNT extra.
    // visibility=visible: excluye productos ocultos del catálogo (p. ej. el
    // producto interno "Cotización Personalizada Nakama").
    $args = array(
        'status' => 'publish',
        'visibility' => 'visible',
        'limit' => $limit + 1,
        'offset' => $offset,
        'orderby' => 'date',
        'order' => 'DESC',
        'return' => 'objects',
    );

    // orderby=sales: más vendidos primero (contador total_sales de WooCommerce).
    if ('sales' === $orderby) {
        $args['orderby'] = 'meta_value_num';
        $args['meta_key'] = 'total_sales';
        $args['order'] = 'DESC';
    }

    // Filtro por categoría (slug). WC 'category' acepta slugs e incluye hijos por defecto.
    if (!empty($category)) {
        $args['category'] = array($category);
    }

    // Filtro por tag (slug).
    if (!empty($tag)) {
        $args['tag'] = array($tag);
    }

    // Búsqueda de texto en título/contenido.
    if (!empty($search)) {
        $args['s'] = $search;
    }

    $wc_products = wc_get_products($args);
    if (!is_array($wc_products)) {
        $wc_products = array();
    }

    // Determinar si hay página siguiente (obtuvimos más de $limit).
    $has_next_page = count($wc_products) > $limit;
    if ($has_next_page) {
        // Descartar el elemento extra usado solo para la detección.
        $wc_products = array_slice($wc_products, 0, $limit);
    }

    // Mapear al shape del frontend (modo ligero: sin descripción ni reseñas).
    $products = array();
    foreach ($wc_products as $wc_product) {
        $built = nakama_products_build_product($wc_product, true);
        if ($built) {
            $products[] = $built;
        }
    }

    // Paginación basada en offset. endCursor = String(offset+limit) si hay más, si no null.
    $end_cursor = $has_next_page ? (string) ($offset + $limit) : null;

    // categories/tags solo se incluyen cuando hay `search` y es la primera página (offset 0).
    $categories = array();
    $tags = array();
    if (!empty($search) && 0 === $offset) {
        $categories = nakama_products_search_categories($search);
        $tags = nakama_products_search_tags($search);
    }

    $payload = array(
        'products' => $products,
        'pageInfo' => array(
            'hasNextPage' => (bool) $has_next_page,
            'endCursor' => $end_cursor,
        ),
        'categories' => $categories,
        'tags' => $tags,
    );

    // Solo cachear respuestas con productos: una vacía (fallo transitorio)
    // dejaría una categoría "sin productos" hasta la siguiente invalidación.
    if (!empty($products)) {
        set_transient($cache_key, $payload, 15 * MINUTE_IN_SECONDS);
    }

    return nakama_products_add_cors(rest_ensure_response($payload));
}

/**
 * Categorías (product_cat) cuyo nombre coincide con la búsqueda.
 * Shape WPCategory = { id, name, slug, parentSlug }.
 */
function nakama_products_search_categories($search)
{
    $terms = get_terms(array(
        'taxonomy' => 'product_cat',
        'hide_empty' => false,
        'search' => $search,
        'number' => 20,
    ));

    if (is_wp_error($terms) || empty($terms)) {
        return array();
    }

    $out = array();
    foreach ($terms as $term) {
        // Resolver el slug del padre (o null si es raíz).
        $parent_slug = null;
        if ($term->parent) {
            $parent = get_term($term->parent, 'product_cat');
            if ($parent && !is_wp_error($parent)) {
                $parent_slug = $parent->slug;
            }
        }

        $out[] = array(
            'id' => (int) $term->term_id,
            'name' => $term->name,
            'slug' => $term->slug,
            'parentSlug' => $parent_slug,
        );
    }

    return $out;
}

/**
 * Tags (product_tag) cuyo nombre coincide con la búsqueda.
 * Shape WPTag = { databaseId, name, slug }.
 */
function nakama_products_search_tags($search)
{
    $terms = get_terms(array(
        'taxonomy' => 'product_tag',
        'hide_empty' => false,
        'search' => $search,
        'number' => 20,
    ));

    if (is_wp_error($terms) || empty($terms)) {
        return array();
    }

    $out = array();
    foreach ($terms as $term) {
        $out[] = array(
            'databaseId' => (int) $term->term_id,
            'name' => $term->name,
            'slug' => $term->slug,
        );
    }

    return $out;
}

// ============================================================================
// 2) HANDLER: PRODUCTO ÚNICO POR SLUG
// ============================================================================
function nakama_products_single($request)
{
    $slug = sanitize_title((string) $request->get_param('slug'));

    if (empty($slug)) {
        return new WP_Error('missing_slug', 'El parámetro slug es requerido', array('status' => 400));
    }

    // Caché servidor por slug (se invalida al guardar cualquier producto).
    $cache_key = nakama_products_cache_key('nkp_single', array($slug));
    $cached = get_transient($cache_key);
    if (false !== $cached && is_array($cached)) {
        return nakama_products_add_cors(rest_ensure_response($cached));
    }

    // Buscar el post por su post_name (slug) dentro del tipo 'product'.
    $post = get_page_by_path($slug, OBJECT, 'product');

    if (!$post || 'publish' !== $post->post_status) {
        return new WP_Error('not_found', 'Producto no encontrado', array('status' => 404));
    }

    $product = wc_get_product($post->ID);
    if (!$product) {
        return new WP_Error('not_found', 'Producto no encontrado', array('status' => 404));
    }

    // Productos ocultos del catálogo (p. ej. el interno de cotizaciones):
    // no exponerlos ni por slug directo.
    if ('hidden' === $product->get_catalog_visibility()) {
        return new WP_Error('not_found', 'Producto no encontrado', array('status' => 404));
    }

    $built = nakama_products_build_product($product);
    if (!$built) {
        return new WP_Error('not_found', 'Producto no encontrado', array('status' => 404));
    }

    set_transient($cache_key, $built, 15 * MINUTE_IN_SECONDS);

    return nakama_products_add_cors(rest_ensure_response($built));
}

// ============================================================================
// 3) HANDLER: LISTA DE SLUGS (rápida, $wpdb directo)
// ============================================================================
function nakama_products_slugs($request)
{
    global $wpdb;

    // Una sola consulta directa a wp_posts por velocidad (se llama en build time).
    // El NOT IN excluye productos ocultos del catálogo/búsqueda (taxonomía
    // product_visibility), como el producto interno de cotizaciones.
    $slugs = $wpdb->get_col(
        $wpdb->prepare(
            "SELECT p.post_name FROM {$wpdb->posts} p
             WHERE p.post_type = %s AND p.post_status = %s AND p.post_name != ''
               AND p.ID NOT IN (
                 SELECT tr.object_id
                 FROM {$wpdb->term_relationships} tr
                 INNER JOIN {$wpdb->term_taxonomy} tt ON tr.term_taxonomy_id = tt.term_taxonomy_id
                 INNER JOIN {$wpdb->terms} t ON tt.term_id = t.term_id
                 WHERE tt.taxonomy = 'product_visibility'
                   AND t.slug IN ('exclude-from-catalog', 'exclude-from-search')
               )",
            'product',
            'publish'
        )
    );

    if (!is_array($slugs)) {
        $slugs = array();
    }

    return nakama_products_add_cors(rest_ensure_response(array(
        'slugs' => array_values($slugs),
    )));
}

// ============================================================================
// 4) HANDLER: MODO MANTENIMIENTO
// ============================================================================
function nakama_get_maintenance_status()
{
    $enabled = get_option('nakama_maintenance_mode', 'off') === 'on';

    $message = get_option('nakama_maintenance_message', 'Estamos preparando nuevos diseños increíbles para ti. ¡Volvemos muy pronto!');
    $image = get_option('nakama_maintenance_image', 'https://nakamabordados.com/wp-content/uploads/2026/05/OPCR05-1.avif');
    $facebook = get_option('nakama_maintenance_fb', 'https://www.facebook.com/Nakamabordados');
    $instagram = get_option('nakama_maintenance_ig', 'https://www.instagram.com/nakama_bordados/');
    $tiktok = get_option('nakama_maintenance_tt', 'https://www.tiktok.com/@nakamabordados');

    return nakama_products_add_cors(rest_ensure_response(array(
        'maintenanceMode' => $enabled,
        'message' => $message,
        'image' => $image,
        'socialLinks' => array(
            'facebook' => $facebook,
            'instagram' => $instagram,
            'tiktok' => $tiktok,
        ),
    )));
}

function nakama_set_maintenance_status($request)
{
    $params = $request->get_json_params();
    $enabled = isset($params['enabled']) ? (bool) $params['enabled'] : false;

    update_option('nakama_maintenance_mode', $enabled ? 'on' : 'off');

    return nakama_products_add_cors(rest_ensure_response(array(
        'success' => true,
        'maintenanceMode' => $enabled,
    )));
}

// Bypassear el chequeo de nonce de WordPress solo para el endpoint de mantenimiento
add_filter('rest_authentication_errors', function ($result) {
    if (is_wp_error($result) && $result->get_error_code() === 'rest_cookie_invalid_nonce') {
        if (isset($_SERVER['REQUEST_URI']) && strpos($_SERVER['REQUEST_URI'], '/nakama/v1/maintenance') !== false) {
            return null; // Bypassear error de nonce
        }
    }
    return $result;
}, 99);
